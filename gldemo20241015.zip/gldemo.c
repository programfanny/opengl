//gcc gldemo.c -o gldemo.exe -mwindows -lopengl32 -lglu32 -lglut32
#define GL_GLEXT_PROTOTYPES
#include <windows.h>
//#include <GL/glew.h>
#include <GL/glut.h>
#include <GL/glu.h>
#include <GL/gl.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>

#define ID_Edit    401
#define ID_List    402
#define ID_EDIT_ENTER   403
// 参数结构体
typedef struct {
	float x1, y1, z1; // 线段起点坐标
	float x2, y2, z2; // 线段终点坐标
} LineParams;

typedef struct {
	float centerX, centerY, centerZ; // 长方体中心坐标
	float length, width, height; // 长方体的长宽高
	float faceDirectionX, faceDirectionY, faceDirectionZ; // 面的方向
} CuboidParams;
// 定义一个联合体来存储所有可能的参数类型
//typedef union {
//	LineParams lineParams;
//	CuboidParams cuboidParams;
//	// 其他参数类型...
//} DrawParams;

// 定义一个结构体来存储绘图函数的参数和索引
//typedef struct {
//	int functionIndex;
//	DrawParams params;
//} DrawFunctionParams;
typedef void (*CommandFunc)(int count, float* paramList);
typedef struct {
    const char* command;
    CommandFunc func;
} CommandTable;
void processLine3f(int count, float* paramList);
void processLine2f(int count, float* paramList);

CommandTable commandTable[] = {
    {"line3f", processLine3f},
    {"line2f", processLine2f},
    // 可以添加更多命令
    {NULL, NULL} // 表尾标识
};
CommandFunc findCommand(const char* command) {
    for (int i = 0; commandTable[i].command != NULL; i++) {
        if (strcmp(commandTable[i].command, command) == 0) {
            return commandTable[i].func;
        }
    }
    return NULL;
}
void parseAndExecute(const char* input);

typedef void (*DrawFunction)(void*);

// 窗口宽度和高度
static const int width = 410;
static const int height = 400;
int functionIndex=1;
void *params = NULL;
WNDPROC OriginalEditProc = NULL;
HGLRC hRC;
HWND hWndMain, hCmdList, hEditBox, hGLCanvas, hGLResult;
UINT timerID;
UINT timerState;

static const char szWindowClass[] = "WindowClass";
static const char szglWindowClass[] = "OpenGLWindowClass";
static const char szglrsWindowClass[] = "ResultWindowClass";
static const char szTitle[] = "OpenGL 3D Graphics";

void gl_Draw();
void RenderScene(HWND hwnd, int functioonIndex, void* functionParams);
int InitOpenGL(HWND hwnd);
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK glWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
LRESULT CALLBACK rsWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
HWND CreateCommandPanel(HINSTANCE hInstance, HWND hwndParent, int left, int top, int width, int height);
HWND CreateCommandEdit(HINSTANCE hInstance, HWND hwndParent, int left, int top, int width, int height);
HWND CreateOpenGLCanvas(HINSTANCE hInstance, HWND hwndParent, int left, int top, int width, int height);
HWND CreateOpenGLResult(HINSTANCE hInstance, HWND hwndParent,int left, int top, int width,int height);

LRESULT CALLBACK EditSubclassProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
	char* buf;
    switch (message) {
        case WM_KEYDOWN:
            if (wParam == VK_RETURN) {
                buf = malloc(300 * sizeof(char));
                GetWindowText(hwnd, buf, 300);
                PostMessage(GetParent(hwnd), WM_COMMAND, ID_EDIT_ENTER, (LPARAM)buf);
                SetWindowText(hwnd, "");
                return 0;
            }
            break;
    }
    return CallWindowProc(OriginalEditProc, hwnd, message, wParam, lParam);
}
void SubclassEditBox(HWND hwndParent, HWND hwndControl, int IDControl, WNDPROC *OriginalProc) {
    HWND hwndEdit = GetDlgItem(hwndParent, IDControl);
    *OriginalProc = (WNDPROC)SetWindowLongPtr(hwndControl, GWLP_WNDPROC, (LONG_PTR)EditSubclassProc);
}
void ShowGLText(float x, float y, float z, char *text){
	void *font = GLUT_BITMAP_HELVETICA_10;
    glRasterPos3f(x, y, z);
    for (int i = 0; text[i] != '\0'; i++) {
        glutBitmapCharacter(font, text[i]);
    }
}
void DrawAxis(){
	glColor3f(0.0f, 1.0f, 1.0f);
	glBegin(GL_LINES);
	glVertex3f(0.0f, 0.0f, 0.0f);
	glVertex3f(1.0f, 0.0f, 0.0f);
	glVertex3f(0.0f, 0.0f, 0.0f);
	glVertex3f(0.0f, 1.0f, 0.0f);
	glVertex3f(0.0f, 0.0f, 0.0f);
	glVertex3f(0.0f, 0.0f, 1.0f);
	glEnd();
	glRasterPos3f(1.0f, 0.0f, 0.0f);
	glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, 'X');
	glRasterPos3f(0.0f, 1.0f, 0.0f);
	glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, 'Y');
	glRasterPos3f(0.0f, 0.0f, 1.0f);
	glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, 'Z');
	ShowGLText(0.0,0.0,0.0,"O-xyz");
}

void DrawVxt(void* params){
// 	GLfloat cube_vertices[8][4] = {
// 	   { -0.5f,  0.5f, -0.5f, 1.0f },
// 	   {  0.5f,  0.5f, -0.5f, 1.0f },
// 	   {  0.5f, -0.5f, -0.5f, 1.0f },
// 	   { -0.5f, -0.5f, -0.5f, 1.0f },
// 	   { -0.5f,  0.5f,  0.5f, 1.0f },
// 	   {  0.5f,  0.5f,  0.5f, 1.0f },
//	   {  0.5f, -0.5f,  0.5f, 1.0f },
//	   { -0.5f, -0.5f,  0.5f, 1.0f }
//	};

	GLfloat axis_vertices[4]={
		(0.0f, 0.0f, 0.0f),
		(0.05f, 0.5f, 0.0f),
		(0.0f, 0.05f, 0.5f),
		(0.5f, 0.0f, 0.05f),
	};
	GLuint indices[] = {0, 1, 2, 3};
	GLsizei numIndices = sizeof(indices) / sizeof(indices[0]);
	const GLubyte* version = glGetString(GL_VERSION);
	char buf[100];
	sprintf(buf,"%s",version);
	ShowGLText(0.0f,0.0f,0.0f,buf);
	

/*	GLuint ebo;
	glGenBuffers(1,&ebo);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, numIndices * sizeof(GLuint), indices, GL_STATIC_DRAW);

	glDrawElements(GL_LINES, numIndices, GL_UNSIGNED_INT, 0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
	glRasterPos3f(0.05f, 0.5f, 0.0f);
	glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, 'A');
	glRasterPos3f(0.0f, 0.05f, 0.5f);
	glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, 'B');
	glRasterPos3f(0.5f, 0.0f, 0.05f);
	glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, 'C');
*/
}


void drawCircle(float cx, float cy, float radius) {
    int num_segments = 100;
    float angle;
    glColor3f(0.0f,0.3f,0.8f);
    glBegin(GL_POLYGON);
    for (int i = 0; i < num_segments; i++) {
        angle = 2.0 * 3.1415926 * i / num_segments; 
        glVertex2f(cos(angle) * radius + cx, sin(angle) * radius + cy);
    }
    glEnd();
}
void drawHollowCircle(float cx, float cy, float radius) {
    int num_segments = 100;
    float angle;
    glColor3f(1.0f, 1.0f, 1.0f);
    glBegin(GL_LINE_LOOP);
    for (int i = 0; i < num_segments; i++) {
        angle = 2.0 * 3.1415926 * i / num_segments; 
        glVertex2f(cos(angle) * radius + cx, sin(angle) * radius + cy);
    }
    glEnd();
    glColor3f(1.0f, 0.0f, 0.0f);
    glBegin(GL_LINES);
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex3f(0.0f, 0.0f,0.0f);
    glVertex2f(cos(3.1415926) * radius + cx, sin(3.1415926) * radius + cy);
    glColor3f(1.0f, 1.0f, 0.0f);
    glVertex3f(0.0f, 0.0f,0.0f);
    glVertex2f(cos(3.1415926/2) * radius + cx, sin(3.1415926/2) * radius + cy);
    glEnd();
}
void display() {
    glClear(GL_COLOR_BUFFER_BIT); // 清除颜色缓冲区
    glLoadIdentity(); // 重置当前的模型观察矩阵
    drawCircle(0.0f, 0.0f, 0.5f); // 绘制半径为0.5的圆
    glFlush(); // 强制执行所有的OpenGL命令
}

void DrawCuboid(void* params) {
	//CuboidParams *cuboidParams = params;
    // 根据 params 中的参数绘制长方体
    // ...
    DrawAxis();
    glColor3f(0.5f,0.0f,0.5f);
    gluSphere(gluNewQuadric(),0.5,10,20);
    
}
void DrawFunction0(void* drawParams){
	drawCircle(0.0, 0.0, 2.0);
	DrawAxis();
}

void DrawFunction1(void* params) { 
	// 实现绘制长方体的函数
	glColor3f(1.0f,0.5f,0.0f);
	glBegin(GL_QUADS);
    glVertex3f(-1.0f, -1.0f, 0.0f); // 顶点 A
    glVertex3f(1.0f, -1.0f, 0.0f);  // 顶点 B
    glVertex3f(1.0f, 1.0f, 0.0f);   // 顶点 C
    glVertex3f(-1.0f, 1.0f, 0.0f);  // 顶点 D
	glEnd();
	DrawAxis();
}
void DrawLine(void* lineParams) { 
	DrawAxis();
/*
	LineParams* params = lineParams;

	glColor3f(1.0f,1.0f,1.0f);
    glBegin(GL_LINES);
    
    glVertex3f(params->x1, params->y1, params->z1);
    glVertex3f(params->x2, params->y2, params->z2);


    glVertex3f(-1.0f, -1.0f, 0.0f); // 顶点 A
    glVertex3f(1.0f, 1.0f, 0.4f);  // 顶点 B
    
    glEnd();
*/    
}

void DrawFunction2(void* params) {
	// 实现绘制其他图形的函数
	drawHollowCircle(0.0, 0.0, 2.0);
	DrawAxis();
}
void DrawFunction3(void* drawParams){ 
	drawHollowCircle(0.0, 0.0, 2.0);
    glPushMatrix(); // 保存当前矩阵
/*    
    glTranslatef(1.0f, 0.0f, 1.0f);     
    glRotatef(45.0f, 0.0f, 0.0f, 1.0f);
    glScalef(1.0f, 2.0f, 0.5f);
*/

    GLfloat scaleMatrix[16] = {
        0.4f, 0.0f, 0.0f, 0.0f,
        0.0f, 0.5f, 0.0f, 0.0f,
        0.0f, 0.0f, 0.7f, 0.0f,
        0.0f, 0.0f, 0.0f, 1.0f
    };
    // 加载缩放矩阵
    glLoadMatrixf(scaleMatrix);

    // 定义旋转矩阵
    GLfloat rotateMatrix[16] = {
        1.0f, 0.0f, 0.0f, 0.0f,
        0.0f, cos(45.0f * M_PI / 180.0f), -sin(45.0f * M_PI / 180.0f), 0.0f,
        0.0f, sin(45.0f * M_PI / 180.0f), cos(45.0f * M_PI / 180.0f), 0.0f,
        0.0f, 0.0f, 0.0f, 1.0f
    };
    // 乘以旋转矩阵
	glMultMatrixf(rotateMatrix);
   	
   	drawHollowCircle(0.0f, 0.0f, 2.0f);
    glPopMatrix(); // 恢复之前的矩阵	
    DrawAxis();
}
void processLine3f(int count, float* paramList) {
	functionIndex = 5;
	params = paramList;
	PostMessage(GetParent(hGLCanvas),WM_KEYDOWN,VK_UP,(LPARAM)functionIndex);
}
void processLine2f(int count, float* paramList) {
	//MessageBox(NULL,"processLine2f  2f  I'm running ","KKK",MB_OK);
	glBegin(GL_LINES);
	glVertex3f(paramList[0],paramList[1],0.0f);
	glVertex3f(paramList[3],paramList[4],0.0f);
	glEnd();
}
void DrawFunction4(void* drawParams){
	//char buf[100];
	DrawAxis();
/*	
	float *coord = drawParams;
	//MessageBox(NULL,"I'm here.","KK",MB_OK);
	glBegin(GL_LINES);
	glVertex3f(coord[0],coord[1],coord[2]);
	glVertex3f(coord[3],coord[4],coord[5]);
	glEnd();
*/
}
// 函数数组
DrawFunction drawFunctions[] = {
	DrawFunction0,
	DrawFunction1,
	DrawFunction2,
	DrawFunction3,
	DrawVxt,
	DrawCuboid,
	DrawLine,
	DrawFunction4,
};

// 全局变量用于存储旋转角度
float xRot = 0.0f;
float yRot = 0.0f;
float zRot = 0.0f;
float Rot = 0.0;

// 定时器回调函数
void TimerFunc(HWND hwnd, UINT message, UINT iTimerID, UINT dwTime) {

}
int InitOpenGL(HWND hwnd) {
	// 获取设备上下文
	HDC hDC;
	hDC = GetDC(hwnd);
	// 设置像素格式
	PIXELFORMATDESCRIPTOR pfd;
	memset(&pfd, 0, sizeof(pfd));
	pfd.nSize = sizeof(pfd);
	pfd.nVersion = 1;
	pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
	pfd.iPixelType = PFD_TYPE_RGBA;
	pfd.cColorBits = 24;
	pfd.cDepthBits = 16;
	pfd.iLayerType = PFD_MAIN_PLANE;

	int format = ChoosePixelFormat(hDC, &pfd);
	SetPixelFormat(hDC, format, &pfd);
	// 创建渲染上下文
	hRC = wglCreateContext(hDC);
	wglMakeCurrent(hDC, hRC);
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	gluPerspective(45.0f, (GLfloat)width / (GLfloat)height, 0.1f, 100.0f);
	gluLookAt(0.0f, 0.0f, 10.0f ,0.0f, 0.0f, 0.0f, 3.0f,4.0f, 5.0f);

	ReleaseDC(hwnd, hDC);
	return TRUE;
}
// RenderScene 函数，接受一个整数参数用于选择绘图函数
void RenderScene(HWND hwnd, int functionIndex, void* functionParams) {
	HDC hDC = GetDC(hwnd);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glRotatef(0.93,0.577,0.577,0.577);
	drawFunctions[functionIndex](functionParams);
	SwapBuffers(hDC);
	ReleaseDC(hwnd, hDC);
}
void ReadEditBox(HWND hEditBox, LineParams* outParams) {
    // 从 hEditBox 读取文本
    char buffer[100];
    GetWindowText(hEditBox, buffer, sizeof(buffer));
    // 解析文本到参数结构体
    sscanf(buffer, "%f %f %f %f %f %f", &outParams->x1, &outParams->y1, &outParams->z1, &outParams->x2, &outParams->y2, &outParams->z2);
}

void ReadEditBoxCuboid(HWND hEditBox, CuboidParams* outParams) {
    // 从 hEditBox 读取文本
    char buffer[100];
    GetWindowText(hEditBox, buffer, sizeof(buffer));
    // 解析文本到参数结构体
    sscanf(buffer, "%f %f %f %f %f %f %f %f %f",
           &outParams->centerX, &outParams->centerY, &outParams->centerZ,
           &outParams->length, &outParams->width, &outParams->height,
           &outParams->faceDirectionX, &outParams->faceDirectionY, &outParams->faceDirectionZ);
}

void parseAndExecute(const char* input){
	// 分析命令行，获取参数并执行命令
	// 
    char command[20];
    float params[6]; // 假设最多6个参数
    int count = 0;
    char *p, *inputCopy;
	inputCopy = strdup(input);
    if(inputCopy==NULL){
        MessageBox(NULL,"Error\nFailed to duplicate input string","parseAndExecute()",MB_OK);
        return;
    }	
    p = strtok(inputCopy, "(");
    if(p==NULL){
        MessageBox(NULL,"Error! P=NULL\n","parseAndExecute()",MB_OK);
        free(inputCopy);
        return;
    }
    strncpy(command, p, sizeof(command)-1);
    command[sizeof(command)-1]='\0';
    p = strtok(NULL, ")");
    if (p != NULL) {
        char *token = strtok(p, ",");
        while (token != NULL && count < sizeof(params) / sizeof(params[0])) {
            params[count++] = atof(token);
            token = strtok(NULL, ",");
        }
        switch(count){
        	case 4:
        		strcat(command,"2f");
        		break;
        	case 6:
        		strcat(command,"3f");
        		break;	
        }
    	CommandFunc func = findCommand(command);
    	if (func) {
    		//MessageBox(NULL,command,"parseAndExecute()",MB_OK);
			func(count, params);

		} else {
			MessageBox(NULL,"Command not found","parseAndExecute()",MB_OK);
		}

    }
    free(inputCopy);
}
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
	WNDCLASSEX wc, glwc, glrs;
	HWND hwnd;
	HDC hdc;
	PAINTSTRUCT ps;
	MSG msg;

	// 注册窗口类
	wc.cbSize = sizeof(WNDCLASSEX);
	wc.style = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = WndProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	wc.hCursor = LoadCursor(NULL, IDC_ARROW);
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	wc.lpszMenuName = NULL;
	wc.lpszClassName = szWindowClass;
	wc.hIconSm = LoadIcon(NULL, IDI_APPLICATION);

	if (!RegisterClassEx(&wc)) {
		MessageBox(NULL, "Window Registration Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}
	// 创建窗口
	hwnd = CreateWindowEx(
		WS_EX_CLIENTEDGE,
		szWindowClass,
		szTitle,
		WS_OVERLAPPEDWINDOW,
		CW_USEDEFAULT, CW_USEDEFAULT, 1080, 450,
		NULL, NULL, hInstance, NULL);

	if (!hwnd) {
		MessageBox(NULL, "Window Creation Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}
	hWndMain = hwnd;
	glwc.cbSize = sizeof(WNDCLASSEX);
	glwc.style = CS_HREDRAW | CS_VREDRAW ;
	glwc.lpfnWndProc = glWndProc;
	glwc.cbClsExtra = 0;
	glwc.cbWndExtra = 0;
	glwc.hInstance = hInstance;
	glwc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	glwc.hCursor = LoadCursor(NULL, IDC_ARROW);
	glwc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	glwc.lpszMenuName = NULL;
	glwc.lpszClassName = szglWindowClass;
	glwc.hIconSm = LoadIcon(NULL, IDI_APPLICATION);

	if (!RegisterClassEx(&glwc)) {
		MessageBox(NULL, "OpenGL Window Registration Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}
	glrs.cbSize = sizeof(WNDCLASSEX);
	glrs.style = CS_HREDRAW | CS_VREDRAW ;
	glrs.lpfnWndProc = rsWndProc;
	glrs.cbClsExtra = 0;
	glrs.cbWndExtra = 0;
	glrs.hInstance = hInstance;
	glrs.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	glrs.hCursor = LoadCursor(NULL, IDC_ARROW);
	glrs.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	glrs.lpszMenuName = NULL;
	glrs.lpszClassName = szglrsWindowClass;
	glrs.hIconSm = LoadIcon(NULL, IDI_APPLICATION);	
	if (!RegisterClassEx(&glrs)) {
		MessageBox(NULL, "OpenGL2 Window Registration Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}	
	// 创建UI组件
	hGLCanvas = CreateOpenGLCanvas(hInstance, hwnd,10,30,410,370);
	hCmdList = CreateCommandPanel(hInstance, hwnd,426,30,205,340);
	hEditBox = CreateCommandEdit(hInstance, hwnd,426,375,205,25);
	// hGLResult = CreateOpenGLResult(hInstance, hwnd,640,30,410,370);
	SubclassEditBox(hwnd, hEditBox, ID_Edit, &OriginalEditProc);
	// 显示窗口
	ShowWindow(hwnd, nCmdShow);
	UpdateWindow(hwnd);
	// 初始化OpenGL
	if (!InitOpenGL(hGLCanvas)) {
		MessageBox(NULL, "OpenGL Initialization Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}
	// if (!InitOpenGL(hGLResult)) {
	// 	MessageBox(NULL, "OpenGL Initialization Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
	// 	return 0;
	// }

	while (GetMessage(&msg, NULL, 0, 0)) {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam) {
	PAINTSTRUCT ps;
	HDC hdc;
	char buf[100],*text;
	static int functionIndex=1,functionCount=sizeof(drawFunctions)/sizeof(drawFunctions[0]);
	switch (message) {
		case WM_CREATE:
			timerState = 0;
			return 0;
		case WM_PAINT:
			hdc = BeginPaint(hwnd, &ps);
			sprintf(buf,"hGLCanvas = %X",hGLCanvas);
			SetWindowText(hwnd, buf);
			sprintf(buf,"functionIndex = %d",functionIndex);
			TextOut(hdc,50,10,buf,strlen(buf));
			EndPaint(hwnd, &ps);
			return 0;
		case WM_COMMAND:
			switch(wParam){
				case ID_EDIT_ENTER:
					hdc = GetDC(hwnd);
					text = (char*)lParam;
					TextOut(hdc,300,10,text,strlen(text));
					parseAndExecute(text);
					free(text);
					SetFocus(hwnd);
					ReleaseDC(hwnd,hdc);
					break;
			}
			return 0;
		case WM_KEYDOWN:
			switch (wParam) {
				case VK_ESCAPE:
					PostMessage(hwnd, WM_DESTROY, 0, 0);
					break;
				case VK_SPACE:
					PostMessage(hGLCanvas, WM_KEYDOWN, VK_F2, 0);
					break;	
				case VK_UP:
					functionIndex = (functionIndex+1)%functionCount;
					PostMessage(hGLCanvas,WM_KEYDOWN,VK_UP,functionIndex);
					break;
				case VK_DOWN:
					functionIndex = (functionIndex+functionCount-1)%functionCount;
					PostMessage(hGLCanvas,WM_KEYDOWN,VK_DOWN,functionIndex);
					break;
			}
			InvalidateRect(hwnd, NULL, TRUE);
			return 0;
		case WM_DESTROY:
			PostQuitMessage(0);
			return 0;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}
LRESULT CALLBACK glWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam){
	PAINTSTRUCT ps;
	HDC hDC;
	char buf[100];
	
	switch (message) {
		case WM_CREATE:
			InitOpenGL(hwnd);
			timerState=0;
			return 0;
		case WM_PAINT:
			hDC = BeginPaint(hwnd, &ps);
			RenderScene(hwnd, functionIndex, params);
			EndPaint(hwnd, &ps);
			return 0;
		case WM_KEYDOWN:
			switch(wParam){
				case VK_F2:					
					if(timerState==0){
						timerState=1;
						timerID = SetTimer(hwnd, 1, 100, NULL);// 设置定时器
					}else{
						timerState=0;
						KillTimer(hwnd, 1);
					}
					return 0;	
				case VK_UP:
				case VK_DOWN:
					functionIndex = lParam;
					RenderScene(hwnd, functionIndex, params);
					break;	
			}
			return 0;
		case WM_TIMER:
			RenderScene(hwnd, functionIndex, params);
			return 0;

		case WM_DESTROY:
			wglMakeCurrent(NULL, NULL);
			wglDeleteContext(hRC);
			KillTimer(hwnd, 1); // 删除定时器
			PostQuitMessage(0);
			return 0;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}
LRESULT CALLBACK rsWndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam){
	HDC hdc;
	PAINTSTRUCT ps;
	switch(message){
		case WM_CREATE:
			InitOpenGL(hwnd);
			return 0;
		case WM_PAINT:
			hdc = BeginPaint(hwnd,&ps);
			EndPaint(hwnd,&ps);
			return 0;
		case WM_DESTROY:

			PostQuitMessage(0);
			return 0;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}

// 创建左侧上部面板
HWND CreateCommandPanel(HINSTANCE hInstance, HWND hwndParent,int left, int top, int width,int height) {
	return CreateWindowEx(0, "listbox","Command List",
		WS_CHILD | WS_VISIBLE | WS_VSCROLL | WS_BORDER,
		left, top, width, height,
		hwndParent, (HMENU)ID_List, hInstance, NULL);
}
// 创建左侧下部编辑框
HWND CreateCommandEdit(HINSTANCE hInstance, HWND hwndParent,int left, int top, int width,int height) {
	return CreateWindowEx(0, "EDIT", NULL,
		WS_CHILD | WS_VISIBLE | WS_BORDER,
		left, top, width, height,
		hwndParent, (HMENU)ID_Edit, hInstance, NULL);
}
// 创建右侧OpenGL绘图区
HWND CreateOpenGLCanvas(HINSTANCE hInstance, HWND hwndParent,int left, int top, int width,int height) {
	return CreateWindowEx(0, szglWindowClass, NULL,
		WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_BORDER,
		left, top, width, height,
		hwndParent, NULL, hInstance, NULL);
}
HWND CreateOpenGLResult(HINSTANCE hInstance, HWND hwndParent,int left, int top, int width,int height) {
	return CreateWindowEx(0, szglrsWindowClass, NULL,
		WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_BORDER,
		left, top, width, height,
		hwndParent, NULL, hInstance, NULL);
}

/*
VBA拷贝图片
Sub CopyImagesToFirstDocument()
    Dim docSource As Document
    Dim docDest As Document
    Dim img As InlineShape
    Dim destPath As String
    Dim filename As String
    Dim i As Integer
    
    ' 设置目标文档路径（第一个Word文档）
    destPath = Dir(ThisDocument.Path & "\*.docx")
    Set docDest = Documents.Open(FileName:=ThisDocument.Path & "\" & destPath)
    
    ' 遍历同一目录下的所有Word文档
    i = 1
    Do While destPath <> ""
        ' 检查是否是目标文档本身
        If destPath <> ThisDocument.Name Then
            Set docSource = Documents.Open(FileName:=ThisDocument.Path & "\" & destPath)
            ' 遍历文档中的所有图片
            For Each img In docSource.InlineShapes
                ' 复制图片到目标文档
                img.Copy
                docDest.Content.Paste
            Next img
            ' 关闭源文档
            docSource.Close False
        End If
        ' 获取下一个文件名
        i = i + 1
        destPath = Dir()
    Loop
    
    ' 保存并关闭目标文档
    docDest.Save
    docDest.Close
    MsgBox "All images have been copied to the first document."
End Sub

Sub CopyImagesToFirstDocument()
    Dim docSource As Document
    Dim docDest As Document
    Dim img As InlineShape
    Dim destPath As String
    Dim filename As String
    Dim i As Integer
    
    ' 设置目标文档（第一个Word文档）
    Set docDest = ThisDocument
    
    ' 遍历同一目录下的所有Word文档
    destPath = Dir(ThisDocument.Path & "\*.docx")
    i = 1
    Do While destPath <> ""
        ' 检查是否是目标文档本身
        If destPath <> ThisDocument.Name Then
            Set docSource = Documents.Open(FileName:=ThisDocument.Path & "\" & destPath)
            ' 遍历文档中的所有图片
            For Each img In docSource.InlineShapes
                ' 将图片复制到剪贴板
                img.Range.Copy
                ' 在目标文档的末尾粘贴图片
                docDest.Content.InsertAfter vbCr
                docDest.Content.Paste
            Next img
            ' 关闭源文档
            docSource.Close False
        End If
        ' 获取下一个文件名
        i = i + 1
        destPath = Dir()
    Loop
    
    ' 提示完成
    MsgBox "All images have been copied to the first document."
End Sub
*/