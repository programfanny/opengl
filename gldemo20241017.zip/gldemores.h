//gldemores.h

#define IDM_FILE_OPEN  				4001
#define IDM_FILE_SAVE  				4002
#define IDM_FILE_SAVE_AS  			4003
#define IDM_FILE_PRINT  			4004
#define IDM_FILE_PRINT_PREVIEW  	4005
#define IDM_APP_EXIT  				4006
#define IDM_EDIT_UNDO  				4007
#define IDM_EDIT_REDO  				4008
#define IDM_EDIT_CUT  				4009
#define IDM_EDIT_COPY  				4010
#define IDM_EDIT_PASTE  			4011
#define IDM_EDIT_PASTE_SPECIAL  	4012
#define IDM_EDIT_FIND  				4013
#define IDM_EDIT_FIND_NEXT  		4014
#define IDM_EDIT_REPLACE  			4015
#define IDM_VIEW_TOOLBARS  			4016
#define IDM_VIEW_STATUS_BAR  		4017
#define IDM_APP_ABOUT  				4018