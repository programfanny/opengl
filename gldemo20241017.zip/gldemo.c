#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include "gldemores.h"

#define ID_EDIT 4000

static TCHAR szAppName[]="OpenGL Demo";
static TCHAR szglWindowClass[]="OpenGlClass";

void gl_draw(int functionIndex, void* functionParams){
	glBegin(GL_LINES);
	glVertex3f(-1.0f,1.0f,0.0f); glColor3f(1.0f,0.0f,0.0f);
	glVertex3f(1.0f,1.0f,0.0f);  glColor3f(0.0f,1.0f,0.0f);
	glEnd();

	glBegin(GL_TRIANGLES);
	glVertex3f(0.0f,1.0f,0.0f);   glColor3f(1.0f,0.0f,0.0f);
	glVertex3f(-1.0f,-1.0f,0.0f); glColor3f(0.0f,1.0f,0.0f);
	glVertex3f(1.0f,-1.0f,0.0f);  glColor3f(0.0f,0.0f,1.0f);
	glEnd();

}
void gl_Show(int functionIndex, void *functionParams){
    //glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    //glLoadIdentity();
 
    //glTranslatef(0.0f, 0.0f, -5.0f);
	//glRotatef(angle, 1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
 
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex3f(-1.0f, 1.0f, -1.0f);
    glVertex3f(-1.0f, -1.0f, -1.0f);
    glVertex3f(1.0f, -1.0f, -1.0f);
    glVertex3f(1.0f, 1.0f, -1.0f);
		
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex3f(1.0f, 1.0f, -1.0f);
    glVertex3f(1.0f, -1.0f, -1.0f);
    glVertex3f(1.0f, -1.0f, 1.0f);
    glVertex3f(1.0f, 1.0f, 1.0f);
    
 
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex3f(-1.0f, 1.0f, 1.0f);
    glVertex3f(-1.0f, -1.0f, 1.0f);
    glVertex3f(1.0f, -1.0f, 1.0f);
    glVertex3f(1.0f, 1.0f, 1.0f);
 
    glColor3f(1.0f, 1.0f, 0.0f);
    glVertex3f(-1.0f, 1.0f, -1.0f);
    glVertex3f(-1.0f, 1.0f, 1.0f);
    glVertex3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.0f, 1.0f, -1.0f);
 
    glColor3f(0.0f, 1.0f, 1.0f);
    glVertex3f(-1.0f, -1.0f, -1.0f);
    glVertex3f(-1.0f, -1.0f, 1.0f);
    glVertex3f(1.0f, -1.0f, 1.0f);
    glVertex3f(1.0f, -1.0f, -1.0f);
 
	//第一个高字 
    glColor3f(1.0f, 0.0f, 1.0f);
    glVertex3f(-1.0f, 1.0f, -1.0f);
     glVertex3f(-1.0f, 1.0f, 1.0f);
    glVertex3f(-1.0f, -1.0f, 1.0f);
    glVertex3f(-1.0f, -1.0f, -1.0f);
	
    glEnd();
    //高的第一笔 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, 0.10f, 0.95f);
    glVertex3f(-1.01f, 0.15f, 0.85f);
    glVertex3f(-1.01f, -0.15f, 0.8f);
    glVertex3f(-1.01f, -0.10f, 0.75f);
	glEnd();
 
    //高的第二笔 
    glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, -0.70f, 0.70f);
    glVertex3f(-1.01f, 0.70f, 0.70f);
    glVertex3f(-1.01f, 0.70f, 0.60f);
    glVertex3f(-1.01f, -0.70f, 0.60f);
	glEnd();
	//高的第三笔口的上 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, 0.40f, 0.50f);
    glVertex3f(-1.01f, -0.40f, 0.50f);
    glVertex3f(-1.01f, -0.40f, 0.40f);
    glVertex3f(-1.01f, 0.40f, 0.40f);
	glEnd();
	//高的第三笔口左 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, 0.40f, 0.40f);
    glVertex3f(-1.01f, 0.30f, 0.40f);
    glVertex3f(-1.01f, 0.30f, 0.00f);
    glVertex3f(-1.01f, 0.40f, 0.00f);
	glEnd();
	//高的第三笔口右 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, -0.30f, 0.40f);
    glVertex3f(-1.01f, -0.40f, 0.40f);
    glVertex3f(-1.01f, -0.40f, 0.00f);
    glVertex3f(-1.01f, -0.30f, 0.00f);
	glEnd();
	//高的第三笔口最后一笔 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, -0.40f, 0.00f);
    glVertex3f(-1.01f, -0.40f, -0.10f);
    glVertex3f(-1.01f, 0.40f, -0.10f);
    glVertex3f(-1.01f, 0.40f, 0.00f);
	glEnd();
 	//高第四笔宝盖头上 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, 0.70f, -0.20f);
    glVertex3f(-1.01f, -0.70f, -0.20f);
    glVertex3f(-1.01f, -0.70f, -0.30f);
    glVertex3f(-1.01f, 0.70f, -0.30f);
	glEnd();
	//高第四笔宝盖头右 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, -0.70f, -0.30f);
    glVertex3f(-1.01f, -0.60f, -0.30f);
    glVertex3f(-1.01f, -0.60f, -0.80f);
    glVertex3f(-1.01f, -0.70f, -0.80f);
	glEnd();
	//高第四笔宝盖头左 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, 0.70f, -0.30f);
    glVertex3f(-1.01f, 0.60f, -0.30f);
    glVertex3f(-1.01f, 0.60f, -0.80f);
    glVertex3f(-1.01f, 0.70f, -0.80f);
	glEnd();
	//对称部分只需要改坐标2 
	//高第五笔口上 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, 0.20f, -0.40f);
    glVertex3f(-1.01f, -0.20f, -0.40f);
    glVertex3f(-1.01f, -0.20f, -0.50f);
    glVertex3f(-1.01f, 0.20f, -0.50f);
	glEnd();
	//高第五笔口左 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, 0.20f, -0.50f);
    glVertex3f(-1.01f, 0.10f, -0.50f);
    glVertex3f(-1.01f, 0.10f, -0.70f);
    glVertex3f(-1.01f, 0.20f, -0.70f);
	glEnd();
	//高第五笔口右 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, -0.20f, -0.50f);
    glVertex3f(-1.01f, -0.10f, -0.50f);
    glVertex3f(-1.01f, -0.10f, -0.70f);
    glVertex3f(-1.01f, -0.20f, -0.70f);
	glEnd();
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, 0.20f, -0.70f);
    glVertex3f(-1.01f, -0.20f, -0.70f);
    glVertex3f(-1.01f, -0.20f, -0.80f);
    glVertex3f(-1.01f, 0.20f, -0.80f);
	glEnd();
	//完成1面 
 
//面2 
        //高的第一笔 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.10f, 0.95f);
    glVertex3f(1.01f, 0.15f, 0.85f);
    glVertex3f(1.01f, -0.15f, 0.8f);
    glVertex3f(1.01f, -0.10f, 0.75f);
	glEnd();
 
    //高的第二笔 
    glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.70f, 0.70f);
    glVertex3f(1.01f, 0.70f, 0.70f);
    glVertex3f(1.01f, 0.70f, 0.60f);
    glVertex3f(1.01f, -0.70f, 0.60f);
	glEnd();
	//高的第三笔口的上 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.40f, 0.50f);
    glVertex3f(1.01f, -0.40f, 0.50f);
    glVertex3f(1.01f, -0.40f, 0.40f);
    glVertex3f(1.01f, 0.40f, 0.40f);
	glEnd();
	//高的第三笔口左 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.40f, 0.40f);
    glVertex3f(1.01f, 0.30f, 0.40f);
    glVertex3f(1.01f, 0.30f, 0.00f);
    glVertex3f(1.01f, 0.40f, 0.00f);
	glEnd();
	//高的第三笔口右 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.30f, 0.40f);
    glVertex3f(1.01f, -0.40f, 0.40f);
    glVertex3f(1.01f, -0.40f, 0.00f);
    glVertex3f(1.01f, -0.30f, 0.00f);
	glEnd();
	//高的第三笔口最后一笔 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.40f, 0.00f);
    glVertex3f(1.01f, -0.40f, -0.10f);
    glVertex3f(1.01f, 0.40f, -0.10f);
    glVertex3f(1.01f, 0.40f, 0.00f);
	glEnd();
 	//高第四笔宝盖头上 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.70f, -0.20f);
    glVertex3f(1.01f, -0.70f, -0.20f);
    glVertex3f(1.01f, -0.70f, -0.30f);
    glVertex3f(1.01f, 0.70f, -0.30f);
	glEnd();
	//高第四笔宝盖头右 
	glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.70f, -0.30f);
    glVertex3f(1.01f, -0.60f, -0.30f);
    glVertex3f(1.01f, -0.60f, -0.80f);
    glVertex3f(1.01f, -0.70f, -0.80f);
	glEnd();
	//高第四笔宝盖头左 
	glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.70f, -0.30f);
    glVertex3f(1.01f, 0.60f, -0.30f);
    glVertex3f(1.01f, 0.60f, -0.80f);
    glVertex3f(1.01f, 0.70f, -0.80f);
	glEnd();
	//对称部分只需要改坐标2 
	//高第五笔口上 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.20f, -0.40f);
    glVertex3f(1.01f, -0.20f, -0.40f);
    glVertex3f(1.01f, -0.20f, -0.50f);
    glVertex3f(1.01f, 0.20f, -0.50f);
	glEnd();
	//高第五笔口左 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.20f, -0.50f);
    glVertex3f(1.01f, 0.10f, -0.50f);
    glVertex3f(1.01f, 0.10f, -0.70f);
    glVertex3f(1.01f, 0.20f, -0.70f);
	glEnd();
	//高第五笔口右 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.20f, -0.50f);
    glVertex3f(1.01f, -0.10f, -0.50f);
    glVertex3f(1.01f, -0.10f, -0.70f);
    glVertex3f(1.01f, -0.20f, -0.70f);
	glEnd();
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.20f, -0.70f);
    glVertex3f(1.01f, -0.20f, -0.70f);
    glVertex3f(1.01f, -0.20f, -0.80f);
    glVertex3f(1.01f, 0.20f, -0.80f);
	glEnd();
	//完成2面
	
	//高的第一笔 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.10f, 0.95f);
    glVertex3f(1.01f, 0.15f, 0.85f);
    glVertex3f(1.01f, -0.15f, 0.8f);
    glVertex3f(1.01f, -0.10f, 0.75f);
	glEnd();
 
    //高的第二笔 
    glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.70f, 0.70f);
    glVertex3f(1.01f, 0.70f, 0.70f);
    glVertex3f(1.01f, 0.70f, 0.60f);
    glVertex3f(1.01f, -0.70f, 0.60f);
	glEnd();
	//高的第三笔口的上 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.40f, 0.50f);
    glVertex3f(1.01f, -0.40f, 0.50f);
    glVertex3f(1.01f, -0.40f, 0.40f);
    glVertex3f(1.01f, 0.40f, 0.40f);
	glEnd();
	//高的第三笔口左 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.40f, 0.40f);
    glVertex3f(1.01f, 0.30f, 0.40f);
    glVertex3f(1.01f, 0.30f, 0.00f);
    glVertex3f(1.01f, 0.40f, 0.00f);
	glEnd();
	//高的第三笔口右 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.30f, 0.40f);
    glVertex3f(1.01f, -0.40f, 0.40f);
    glVertex3f(1.01f, -0.40f, 0.00f);
    glVertex3f(1.01f, -0.30f, 0.00f);
	glEnd();
	//高的第三笔口最后一笔 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.40f, 0.00f);
    glVertex3f(1.01f, -0.40f, -0.10f);
    glVertex3f(1.01f, 0.40f, -0.10f);
    glVertex3f(1.01f, 0.40f, 0.00f);
	glEnd();
 	//高第四笔宝盖头上 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.70f, -0.20f);
    glVertex3f(1.01f, -0.70f, -0.20f);
    glVertex3f(1.01f, -0.70f, -0.30f);
    glVertex3f(1.01f, 0.70f, -0.30f);
	glEnd();
	//高第四笔宝盖头右 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.70f, -0.30f);
    glVertex3f(1.01f, -0.60f, -0.30f);
    glVertex3f(1.01f, -0.60f, -0.80f);
    glVertex3f(1.01f, -0.70f, -0.80f);
	glEnd();
	//高第四笔宝盖头左 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.70f, -0.30f);
    glVertex3f(1.01f, 0.60f, -0.30f);
    glVertex3f(1.01f, 0.60f, -0.80f);
    glVertex3f(1.01f, 0.70f, -0.80f);
	glEnd();
	//对称部分只需要改坐标2 
	//高第五笔口上 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.20f, -0.40f);
    glVertex3f(1.01f, -0.20f, -0.40f);
    glVertex3f(1.01f, -0.20f, -0.50f);
    glVertex3f(1.01f, 0.20f, -0.50f);
	glEnd();
	//高第五笔口左 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.20f, -0.50f);
    glVertex3f(1.01f, 0.10f, -0.50f);
    glVertex3f(1.01f, 0.10f, -0.70f);
    glVertex3f(1.01f, 0.20f, -0.70f);
	glEnd();
	//高第五笔口右 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.20f, -0.50f);
    glVertex3f(1.01f, -0.10f, -0.50f);
    glVertex3f(1.01f, -0.10f, -0.70f);
    glVertex3f(1.01f, -0.20f, -0.70f);
	glEnd();
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.20f, -0.70f);
    glVertex3f(1.01f, -0.20f, -0.70f);
    glVertex3f(1.01f, -0.20f, -0.80f);
    glVertex3f(1.01f, 0.20f, -0.80f);
	glEnd();
	//开始面3 
	//高的第一笔 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.10f, 1.01f,0.95f);
    glVertex3f( 0.15f, 1.01f,0.85f);
    glVertex3f( -0.15f,1.01f, 0.8f);
    glVertex3f( -0.10f,1.01f, 0.75f);
	glEnd();
 
    //高的第二笔 
    glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.70f,1.01f, 0.70f);
    glVertex3f( 0.70f, 1.01f,0.70f);
    glVertex3f( 0.70f, 1.01f,0.60f);
    glVertex3f( -0.70f,1.01f, 0.60f);
	glEnd();
	//高的第三笔口的上 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.40f,1.01f, 0.50f);
    glVertex3f( -0.40f,1.01f, 0.50f);
    glVertex3f( -0.40f,1.01f, 0.40f);
    glVertex3f( 0.40f,1.01f, 0.40f);
	glEnd();
	//高的第三笔口左 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.40f,1.01f, 0.40f);
    glVertex3f( 0.30f,1.01f, 0.40f);
    glVertex3f( 0.30f,1.01f, 0.00f);
    glVertex3f( 0.40f,1.01f, 0.00f);
	glEnd();
	//高的第三笔口右 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.30f,1.01f, 0.40f);
    glVertex3f( -0.40f,1.01f, 0.40f);
    glVertex3f( -0.40f,1.01f, 0.00f);
    glVertex3f( -0.30f,1.01f, 0.00f);
	glEnd();
	//高的第三笔口最后一笔 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.40f,1.01f, 0.00f);
    glVertex3f( -0.40f,1.01f, -0.10f);
    glVertex3f( 0.40f, 1.01f,-0.10f);
    glVertex3f( 0.40f, 1.01f,0.00f);
	glEnd();
 	//高第四笔宝盖头上 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.70f, 1.01f,-0.20f);
    glVertex3f( -0.70f,1.01f, -0.20f);
    glVertex3f( -0.70f,1.01f, -0.30f);
    glVertex3f( 0.70f, 1.01f,-0.30f);
	glEnd();              
	//高第四笔宝盖头右    
	glBegin(GL_QUADS);    
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.70f,1.01f,-0.30f);
    glVertex3f( -0.60f,1.01f,-0.30f);
    glVertex3f( -0.60f,1.01f,-0.80f);
    glVertex3f( -0.70f,1.01f,-0.80f);
	glEnd();
	//高第四笔宝盖头左 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.70f,1.01f,-0.30f);
    glVertex3f( 0.60f,1.01f,-0.30f);
    glVertex3f( 0.60f,1.01f,-0.80f);
    glVertex3f( 0.70f,1.01f,-0.80f);
	glEnd();             
	//对称部分只需要改坐标,2 
	//高第五笔口上       
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.20f, 1.01f,-0.40f);
    glVertex3f( -0.20f,1.01f, -0.40f);
    glVertex3f( -0.20f,1.01f, -0.50f);
    glVertex3f( 0.20f, 1.01f,-0.50f);
	glEnd();
	//高第五笔口左 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.20f,1.01f,-0.50f);
    glVertex3f( 0.10f,1.01f,-0.50f);
    glVertex3f( 0.10f,1.01f,-0.70f);
    glVertex3f( 0.20f,1.01f,-0.70f);
	glEnd();
	//高第五笔口右 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.20f,1.01f,-0.50f);
    glVertex3f( -0.10f,1.01f,-0.50f);
    glVertex3f( -0.10f,1.01f,-0.70f);
    glVertex3f( -0.20f,1.01f,-0.70f);
	glEnd();              
	glBegin(GL_QUADS);    
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.20f, 1.01f,-0.70f);
    glVertex3f( -0.20f,1.01f, -0.70f);
    glVertex3f( -0.20f,1.01f, -0.80f);
    glVertex3f( 0.20f, 1.01f,-0.80f);
	glEnd();
	
	//完成3面
	//开始画数字00 
	//数字面1 
	
	//左0 上 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.90f, -1.01f,0.70f);
    glVertex3f( 0.20f, -1.01f,0.70f);
    glVertex3f( 0.2f,-1.01f, 0.6f);
    glVertex3f( 0.9f,-1.01f, 0.6f);
	glEnd();
	//左0 左 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.90f, -1.01f,0.60f);
    glVertex3f( 0.80f, -1.01f,0.60f);
    glVertex3f( 0.8f,-1.01f, -0.6f);
    glVertex3f( 0.9f,-1.01f, -0.6f);
	glEnd();
	//左0 右 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.20f, -1.01f,0.60f);
    glVertex3f( 0.30f, -1.01f,0.60f);
    glVertex3f( 0.3f,-1.01f, -0.6f);
    glVertex3f( 0.2f,-1.01f, -0.6f);
	glEnd();
	
	//左0 下 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.90f, -1.01f,-0.70f);
    glVertex3f( 0.20f, -1.01f,-0.70f);
    glVertex3f( 0.2f,-1.01f, -0.6f);
    glVertex3f( 0.9f,-1.01f, -0.6f);
	glEnd();
	
	
	
		//右0 上 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.90f, -1.01f,0.70f);
    glVertex3f( -0.20f, -1.01f,0.70f);
    glVertex3f( -0.2f,-1.01f, 0.6f);
    glVertex3f( -0.9f,-1.01f, 0.6f);
	glEnd();
	//右0 左 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.90f, -1.01f,0.60f);
    glVertex3f( -0.80f, -1.01f,0.60f);
    glVertex3f( -0.8f,-1.01f, -0.6f);
    glVertex3f( -0.9f,-1.01f, -0.6f);
	glEnd();
	//右0 右 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.20f, -1.01f,0.60f);
    glVertex3f( -0.30f, -1.01f,0.60f);
    glVertex3f( -0.3f,-1.01f, -0.6f);
    glVertex3f( -0.2f,-1.01f, -0.6f);
	glEnd();
	
	//右0 上 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.90f, -1.01f,-0.70f);
    glVertex3f( -0.20f, -1.01f,-0.70f);
    glVertex3f( -0.2f,-1.01f, -0.6f);
    glVertex3f( -0.9f,-1.01f, -0.6f);
	glEnd();
	
	//数字面3
	
	//左0 上 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.90f, 0.70f,1.01f);
    glVertex3f( 0.20f, 0.70f,1.01f);
    glVertex3f( 0.2f, 0.6f,1.01f);
    glVertex3f( 0.9f, 0.6f,1.01f);
	glEnd();                 
	//左0 左 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.90f, 0.60f,1.01f);
    glVertex3f( 0.80f, 0.60f,1.01f);
    glVertex3f( 0.8f,  -0.6f,1.01f);
    glVertex3f( 0.9f,  -0.6f,1.01f);
	glEnd();
	//左0 右 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.20f, 0.60f,1.01f);
    glVertex3f( 0.30f, 0.60f,1.01f);
    glVertex3f( 0.3f,  -0.6f,1.01f);
    glVertex3f( 0.2f,  -0.6f,1.01f);
	glEnd();
	
	//左0 下 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.90f, -0.70f,1.01f);
    glVertex3f( 0.20f, -0.70f,1.01f);
    glVertex3f( 0.2f,   -0.6f,1.01f);
    glVertex3f( 0.9f,   -0.6f,1.01f);
	glEnd();
	
		//右0 上 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.90f, 0.70f,1.01f);
    glVertex3f( -0.20f, 0.70f,1.01f);
    glVertex3f( -0.2f,   0.6f,1.01f);
    glVertex3f( -0.9f,   0.6f,1.01f);
	glEnd();
	//右0 左 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.90f, 0.60f,1.01f);
    glVertex3f( -0.80f, 0.60f,1.01f);
    glVertex3f( -0.8f,  -0.6f,1.01f);
    glVertex3f( -0.9f,  -0.6f,1.01f);
	glEnd();
	//右0 右 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.20f,0.60f,1.01f);
    glVertex3f( -0.30f,0.60f,1.01f);
    glVertex3f( -0.3f, -0.6f,1.01f);
    glVertex3f( -0.2f, -0.6f,1.01f);
	glEnd();
	
	//右0 上 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.90f, -0.70f,1.01f);
    glVertex3f( -0.20f, -0.70f,1.01f);
    glVertex3f( -0.2f,   -0.6f,1.01f);
    glVertex3f( -0.9f,   -0.6f,1.01f);
	glEnd();
	
	//数字面12
	
	//左0 上 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.90f, 0.70f,-1.01f);
    glVertex3f( 0.20f, 0.70f,-1.01f);
    glVertex3f( 0.2f, 0.6f,-1.01f);
    glVertex3f( 0.9f, 0.6f,-1.01f);
	glEnd();                 
	//左0 左 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.90f, 0.60f,-1.01f);
    glVertex3f( 0.80f, 0.60f,-1.01f);
    glVertex3f( 0.8f,  -0.6f,-1.01f);
    glVertex3f( 0.9f,  -0.6f,-1.01f);
	glEnd();
	//左0 右 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.20f, 0.60f,-1.01f);
    glVertex3f( 0.30f, 0.60f,-1.01f);
    glVertex3f( 0.3f,  -0.6f,-1.01f);
    glVertex3f( 0.2f,  -0.6f,-1.01f);
	glEnd();
	
	//左0 下 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.90f, -0.70f,-1.01f);
    glVertex3f( 0.20f, -0.70f,-1.01f);
    glVertex3f( 0.2f,   -0.6f,-1.01f);
    glVertex3f( 0.9f,   -0.6f,-1.01f);
	glEnd();
	
	
	
		//右0 上 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.90f, 0.70f,-1.01f);
    glVertex3f( -0.20f, 0.70f,-1.01f);
    glVertex3f( -0.2f,   0.6f,-1.01f);
    glVertex3f( -0.9f,   0.6f,-1.01f);
	glEnd();
	//右0 左 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.90f, 0.60f,-1.01f);
    glVertex3f( -0.80f, 0.60f,-1.01f);
    glVertex3f( -0.8f,  -0.6f,-1.01f);
    glVertex3f( -0.9f,  -0.6f,-1.01f);
	glEnd();
	//右0 右 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.20f,0.60f,-1.01f);
    glVertex3f( -0.30f,0.60f,-1.01f);
    glVertex3f( -0.3f, -0.6f,-1.01f);
    glVertex3f( -0.2f, -0.6f,-1.01f);
	glEnd();
	
	//右0 上 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.90f, -0.70f,-1.01f);
    glVertex3f( -0.20f, -0.70f,-1.01f);
    glVertex3f( -0.2f,   -0.6f,-1.01f);
    glVertex3f( -0.9f,   -0.6f,-1.01f);
	glEnd();
	
    //angle++;
}	
int InitOpenGL(HWND hwnd, HGLRC* hRC) {
	// 获取设备上下文
	HDC hDC;
	hDC = GetDC(hwnd);
	// 设置像素格式
	PIXELFORMATDESCRIPTOR pfd;
	memset(&pfd, 0, sizeof(pfd));
	pfd.nSize = sizeof(pfd);
	pfd.nVersion = 1;
	pfd.dwFlags = PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
	pfd.iPixelType = PFD_TYPE_RGBA;
	pfd.cColorBits = 24;
	pfd.cDepthBits = 16;
	pfd.iLayerType = PFD_MAIN_PLANE;

	int format = ChoosePixelFormat(hDC, &pfd);
	SetPixelFormat(hDC, format, &pfd);
	// 创建渲染上下文
	*hRC = wglCreateContext(hDC);

	ReleaseDC(hwnd, hDC);
	return TRUE;
}
void GLSetup(HDC hDC, HGLRC hRC, int width,int height){
	wglMakeCurrent(hDC, hRC);
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	gluPerspective(45.0f, (GLfloat)width / (GLfloat)height, 0.1f, 100.0f);
	gluLookAt(0.0f, 0.0f, 10.0f ,0.0f, 0.0f, 0.0f, 0.0f,1.0f, 0.0f);
}
void RenderScene(HWND hwnd, int functionIndex, void* functionParams) {
	HDC hDC = GetDC(hwnd);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glRotatef(0.03,0.577,0.577,0.577);
	gl_Show(functionIndex, functionParams);
	SwapBuffers(hDC);
	ReleaseDC(hwnd, hDC);
}
HWND CreateOpenGLCanvas(HINSTANCE hInstance, HWND hwndParent,int left, int top, int width,int height) {
	return CreateWindowEx(0, szglWindowClass, NULL,
		WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_BORDER,
		left, top, width, height,
		hwndParent, NULL, hInstance, NULL);
}
LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
LRESULT CALLBACK glWndProc(HWND,UINT,WPARAM,LPARAM);
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR szCmdLine, int nCmdShow){

	HWND hwnd;
	MSG msg;
	WNDCLASS wndclass;
	wndclass.style=CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc = WndProc;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra=0;
	wndclass.hInstance = hInstance;
	wndclass.hIcon = LoadIcon(NULL,IDI_APPLICATION);
	wndclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndclass.lpszMenuName = "OpenGLMENU";
	wndclass.lpszClassName = szAppName;
	if(!RegisterClass(&wndclass)){
		MessageBox(NULL,TEXT("This program requires Windows NT!"),szAppName, MB_ICONERROR);
		return 0;
	}
	WNDCLASS glwc;
	glwc.style = CS_HREDRAW | CS_VREDRAW ;
	glwc.lpfnWndProc = glWndProc;
	glwc.cbClsExtra = 0;
	glwc.cbWndExtra = 0;
	glwc.hInstance = hInstance;
	glwc.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	glwc.hCursor = LoadCursor(NULL, IDC_ARROW);
	glwc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	glwc.lpszMenuName = NULL;
	glwc.lpszClassName = szglWindowClass;

	if (!RegisterClass(&glwc)) {
		MessageBox(NULL, "OpenGL Window Registration Failed!", "Error!", MB_ICONEXCLAMATION | MB_OK);
		return 0;
	}
	hwnd = CreateWindow(szAppName, TEXT("OpenGL Demo"),WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,CW_USEDEFAULT,NULL,NULL,hInstance,NULL);
	ShowWindow(hwnd, nCmdShow);
	UpdateWindow(hwnd);
	while(GetMessage(&msg,NULL,0,0)){
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	return msg.wParam;
}
LRESULT CALLBACK WndProc(HWND hwnd,UINT message,WPARAM wParam,LPARAM lParam){
	HINSTANCE hInstance;
	//HDC hdc;
	//HGLRC hRC;
	//PAINTSTRUCT ps;
	//RECT rect;

	static HWND glwnd;
	//static HWND hEditbox;

	switch(message){
		case WM_CREATE:
			hInstance = ((LPCREATESTRUCT)lParam)->hInstance;
			glwnd = CreateWindow(szglWindowClass, NULL,	WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | WS_BORDER, 10,0,410,370, hwnd, NULL, hInstance, NULL);
			/*hEditbox =*/ CreateWindow( "EDIT", NULL,WS_CHILD | WS_VISIBLE | WS_BORDER, 10,380,410,25, hwnd, (HMENU)ID_EDIT, hInstance, NULL);
			return 0;
		case WM_PAINT:
			PostMessage(glwnd,WM_PAINT,0,0);
			return 0;
		case WM_COMMAND:
			switch(wParam){
				case IDM_APP_EXIT:
					PostMessage(hwnd,WM_DESTROY,0,0);
					break;
				case IDM_FILE_OPEN:

					break;
				case IDM_FILE_SAVE:
					break;
				case IDM_FILE_SAVE_AS:
					break;
				case IDM_FILE_PRINT:
					break;
				case IDM_FILE_PRINT_PREVIEW:
					break;
				case IDM_EDIT_UNDO:
					break;
				case IDM_EDIT_REDO:
					break;
				case IDM_EDIT_CUT:
					break;
				case IDM_EDIT_COPY:
					break;
				case IDM_EDIT_PASTE:
					break;
				case IDM_EDIT_PASTE_SPECIAL:
					break;
				case IDM_EDIT_FIND:
					break;
				case IDM_EDIT_FIND_NEXT:
					break;
				case IDM_EDIT_REPLACE:
					break;
				case IDM_VIEW_TOOLBARS:
					break;
				case IDM_VIEW_STATUS_BAR:
					break;
				case IDM_APP_ABOUT:
					//MessageBox(NULL, "OpenGL Programming Demo","About This APP", MB_OK);

					break;  				
			}
			return 0;	
		case WM_KEYDOWN:
			switch(wParam){
				case VK_ESCAPE:
					PostMessage(hwnd,WM_DESTROY,0,0);
					break;

			}
			return 0;
		case WM_DESTROY:
			PostQuitMessage(0);
			return 0;			
	}
	return DefWindowProc(hwnd, message, wParam, lParam);

}

LRESULT CALLBACK glWndProc(HWND hwnd,UINT message,WPARAM wParam,LPARAM lParam){
	static HGLRC hRC;
	static HDC hDC;
	switch(message){
		case WM_CREATE:
			hDC = GetDC(hwnd);
			InitOpenGL(hwnd, &hRC);
			GLSetup(hDC,hRC, 400, 400);
			ReleaseDC(hwnd, hDC);
			return 0;
		case WM_PAINT:
			RenderScene(hwnd, 0, NULL);
			return 0;
		case WM_DESTROY:
			wglMakeCurrent(NULL, NULL);
			wglDeleteContext(hRC);
			PostQuitMessage(0);
			return 0;		
	}
	return DefWindowProc(hwnd, message, wParam, lParam);	
}
/*
//提升权限
#include <windows.h>
#include <wchar.h>
 
int main() {
    HANDLE hToken;
    STARTUPINFO si = {0};
    PROCESS_INFORMATION pi;
    BOOL fRet;
    DWORD dwSessionID;
 
    // 获取当前会话ID
    dwSessionID = WTSGetActiveConsoleSessionId();
 
    // 打开当前的token
    if (!WTSQueryUserToken(WTSGetActiveConsoleSessionId(), &hToken)) {
        printf("WTSQueryUserToken failed with %d\n", GetLastError());
        return 1;
    }
 
    // 设置启动信息结构体
    si.cb = sizeof(si);
 
    // 创建一个以系统权限运行的进程
    fRet = CreateProcessAsUserW(
        hToken,            // 用户的token
        NULL,              // 可执行文件名
        L"cmd.exe",        // 命令行参数
        NULL,              // 安全属性
        NULL,              // 线程安全属性
        FALSE,             // 是否继承句柄
        CREATE_NEW_CONSOLE,// 创建标志
        NULL,              // 环境变量
        NULL,              // 当前目录
        &si,               // 启动信息
        &pi                // 进程信息
    );
 
    if (!fRet) {
        printf("CreateProcessAsUser failed with %d\n", GetLastError());
    } else {
        // 等待新进程结束
        WaitForSingleObject(pi.hProcess, INFINITE);
        CloseHandle(pi.hProcess);
        CloseHandle(pi.hThread);
    }
 
    CloseHandle(hToken);
 
    return 0;
}
*/
/*
static int angle = 0;
 
void display()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
 
    glTranslatef(0.0f, 0.0f, -5.0f);
	glRotatef(angle, 1.0f, 1.0f, 1.0f);
    glBegin(GL_QUADS);
 
    glColor3f(1.0f, 0.0f, 0.0f);
    glVertex3f(-1.0f, 1.0f, -1.0f);
    glVertex3f(-1.0f, -1.0f, -1.0f);
    glVertex3f(1.0f, -1.0f, -1.0f);
    glVertex3f(1.0f, 1.0f, -1.0f);
		
    glColor3f(0.0f, 1.0f, 0.0f);
    glVertex3f(1.0f, 1.0f, -1.0f);
    glVertex3f(1.0f, -1.0f, -1.0f);
    glVertex3f(1.0f, -1.0f, 1.0f);
    glVertex3f(1.0f, 1.0f, 1.0f);
    
 
    glColor3f(0.0f, 0.0f, 1.0f);
    glVertex3f(-1.0f, 1.0f, 1.0f);
    glVertex3f(-1.0f, -1.0f, 1.0f);
    glVertex3f(1.0f, -1.0f, 1.0f);
    glVertex3f(1.0f, 1.0f, 1.0f);
 
    glColor3f(1.0f, 1.0f, 0.0f);
    glVertex3f(-1.0f, 1.0f, -1.0f);
    glVertex3f(-1.0f, 1.0f, 1.0f);
    glVertex3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.0f, 1.0f, -1.0f);
 
    glColor3f(0.0f, 1.0f, 1.0f);
    glVertex3f(-1.0f, -1.0f, -1.0f);
    glVertex3f(-1.0f, -1.0f, 1.0f);
    glVertex3f(1.0f, -1.0f, 1.0f);
    glVertex3f(1.0f, -1.0f, -1.0f);
 
	//第一个高字 
    glColor3f(1.0f, 0.0f, 1.0f);
    glVertex3f(-1.0f, 1.0f, -1.0f);
    glVertex3f(-1.0f, 1.0f, 1.0f);
    glVertex3f(-1.0f, -1.0f, 1.0f);
    glVertex3f(-1.0f, -1.0f, -1.0f);
	
    glEnd();
    //高的第一笔 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, 0.10f, 0.95f);
    glVertex3f(-1.01f, 0.15f, 0.85f);
    glVertex3f(-1.01f, -0.15f, 0.8f);
    glVertex3f(-1.01f, -0.10f, 0.75f);
	glEnd();
 
    //高的第二笔 
    glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, -0.70f, 0.70f);
    glVertex3f(-1.01f, 0.70f, 0.70f);
    glVertex3f(-1.01f, 0.70f, 0.60f);
    glVertex3f(-1.01f, -0.70f, 0.60f);
	glEnd();
	//高的第三笔口的上 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, 0.40f, 0.50f);
    glVertex3f(-1.01f, -0.40f, 0.50f);
    glVertex3f(-1.01f, -0.40f, 0.40f);
    glVertex3f(-1.01f, 0.40f, 0.40f);
	glEnd();
	//高的第三笔口左 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, 0.40f, 0.40f);
    glVertex3f(-1.01f, 0.30f, 0.40f);
    glVertex3f(-1.01f, 0.30f, 0.00f);
    glVertex3f(-1.01f, 0.40f, 0.00f);
	glEnd();
	//高的第三笔口右 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, -0.30f, 0.40f);
    glVertex3f(-1.01f, -0.40f, 0.40f);
    glVertex3f(-1.01f, -0.40f, 0.00f);
    glVertex3f(-1.01f, -0.30f, 0.00f);
	glEnd();
	//高的第三笔口最后一笔 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, -0.40f, 0.00f);
    glVertex3f(-1.01f, -0.40f, -0.10f);
    glVertex3f(-1.01f, 0.40f, -0.10f);
    glVertex3f(-1.01f, 0.40f, 0.00f);
	glEnd();
 	//高第四笔宝盖头上 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, 0.70f, -0.20f);
    glVertex3f(-1.01f, -0.70f, -0.20f);
    glVertex3f(-1.01f, -0.70f, -0.30f);
    glVertex3f(-1.01f, 0.70f, -0.30f);
	glEnd();
	//高第四笔宝盖头右 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, -0.70f, -0.30f);
    glVertex3f(-1.01f, -0.60f, -0.30f);
    glVertex3f(-1.01f, -0.60f, -0.80f);
    glVertex3f(-1.01f, -0.70f, -0.80f);
	glEnd();
	//高第四笔宝盖头左 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, 0.70f, -0.30f);
    glVertex3f(-1.01f, 0.60f, -0.30f);
    glVertex3f(-1.01f, 0.60f, -0.80f);
    glVertex3f(-1.01f, 0.70f, -0.80f);
	glEnd();
	//对称部分只需要改坐标2 
	//高第五笔口上 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, 0.20f, -0.40f);
    glVertex3f(-1.01f, -0.20f, -0.40f);
    glVertex3f(-1.01f, -0.20f, -0.50f);
    glVertex3f(-1.01f, 0.20f, -0.50f);
	glEnd();
	//高第五笔口左 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, 0.20f, -0.50f);
    glVertex3f(-1.01f, 0.10f, -0.50f);
    glVertex3f(-1.01f, 0.10f, -0.70f);
    glVertex3f(-1.01f, 0.20f, -0.70f);
	glEnd();
	//高第五笔口右 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, -0.20f, -0.50f);
    glVertex3f(-1.01f, -0.10f, -0.50f);
    glVertex3f(-1.01f, -0.10f, -0.70f);
    glVertex3f(-1.01f, -0.20f, -0.70f);
	glEnd();
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(-1.01f, 0.20f, -0.70f);
    glVertex3f(-1.01f, -0.20f, -0.70f);
    glVertex3f(-1.01f, -0.20f, -0.80f);
    glVertex3f(-1.01f, 0.20f, -0.80f);
	glEnd();
	//完成1面 
 
//面2 
        //高的第一笔 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.10f, 0.95f);
    glVertex3f(1.01f, 0.15f, 0.85f);
    glVertex3f(1.01f, -0.15f, 0.8f);
    glVertex3f(1.01f, -0.10f, 0.75f);
	glEnd();
 
    //高的第二笔 
    glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.70f, 0.70f);
    glVertex3f(1.01f, 0.70f, 0.70f);
    glVertex3f(1.01f, 0.70f, 0.60f);
    glVertex3f(1.01f, -0.70f, 0.60f);
	glEnd();
	//高的第三笔口的上 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.40f, 0.50f);
    glVertex3f(1.01f, -0.40f, 0.50f);
    glVertex3f(1.01f, -0.40f, 0.40f);
    glVertex3f(1.01f, 0.40f, 0.40f);
	glEnd();
	//高的第三笔口左 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.40f, 0.40f);
    glVertex3f(1.01f, 0.30f, 0.40f);
    glVertex3f(1.01f, 0.30f, 0.00f);
    glVertex3f(1.01f, 0.40f, 0.00f);
	glEnd();
	//高的第三笔口右 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.30f, 0.40f);
    glVertex3f(1.01f, -0.40f, 0.40f);
    glVertex3f(1.01f, -0.40f, 0.00f);
    glVertex3f(1.01f, -0.30f, 0.00f);
	glEnd();
	//高的第三笔口最后一笔 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.40f, 0.00f);
    glVertex3f(1.01f, -0.40f, -0.10f);
    glVertex3f(1.01f, 0.40f, -0.10f);
    glVertex3f(1.01f, 0.40f, 0.00f);
	glEnd();
 	//高第四笔宝盖头上 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.70f, -0.20f);
    glVertex3f(1.01f, -0.70f, -0.20f);
    glVertex3f(1.01f, -0.70f, -0.30f);
    glVertex3f(1.01f, 0.70f, -0.30f);
	glEnd();
	//高第四笔宝盖头右 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.70f, -0.30f);
    glVertex3f(1.01f, -0.60f, -0.30f);
    glVertex3f(1.01f, -0.60f, -0.80f);
    glVertex3f(1.01f, -0.70f, -0.80f);
	glEnd();
	//高第四笔宝盖头左 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.70f, -0.30f);
    glVertex3f(1.01f, 0.60f, -0.30f);
    glVertex3f(1.01f, 0.60f, -0.80f);
    glVertex3f(1.01f, 0.70f, -0.80f);
	glEnd();
	//对称部分只需要改坐标2 
	//高第五笔口上 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.20f, -0.40f);
    glVertex3f(1.01f, -0.20f, -0.40f);
    glVertex3f(1.01f, -0.20f, -0.50f);
    glVertex3f(1.01f, 0.20f, -0.50f);
	glEnd();
	//高第五笔口左 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.20f, -0.50f);
    glVertex3f(1.01f, 0.10f, -0.50f);
    glVertex3f(1.01f, 0.10f, -0.70f);
    glVertex3f(1.01f, 0.20f, -0.70f);
	glEnd();
	//高第五笔口右 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.20f, -0.50f);
    glVertex3f(1.01f, -0.10f, -0.50f);
    glVertex3f(1.01f, -0.10f, -0.70f);
    glVertex3f(1.01f, -0.20f, -0.70f);
	glEnd();
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.20f, -0.70f);
    glVertex3f(1.01f, -0.20f, -0.70f);
    glVertex3f(1.01f, -0.20f, -0.80f);
    glVertex3f(1.01f, 0.20f, -0.80f);
	glEnd();
	//完成2面
	
	//高的第一笔 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.10f, 0.95f);
    glVertex3f(1.01f, 0.15f, 0.85f);
    glVertex3f(1.01f, -0.15f, 0.8f);
    glVertex3f(1.01f, -0.10f, 0.75f);
	glEnd();
 
    //高的第二笔 
    glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.70f, 0.70f);
    glVertex3f(1.01f, 0.70f, 0.70f);
    glVertex3f(1.01f, 0.70f, 0.60f);
    glVertex3f(1.01f, -0.70f, 0.60f);
	glEnd();
	//高的第三笔口的上 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.40f, 0.50f);
    glVertex3f(1.01f, -0.40f, 0.50f);
    glVertex3f(1.01f, -0.40f, 0.40f);
    glVertex3f(1.01f, 0.40f, 0.40f);
	glEnd();
	//高的第三笔口左 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.40f, 0.40f);
    glVertex3f(1.01f, 0.30f, 0.40f);
    glVertex3f(1.01f, 0.30f, 0.00f);
    glVertex3f(1.01f, 0.40f, 0.00f);
	glEnd();
	//高的第三笔口右 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.30f, 0.40f);
    glVertex3f(1.01f, -0.40f, 0.40f);
    glVertex3f(1.01f, -0.40f, 0.00f);
    glVertex3f(1.01f, -0.30f, 0.00f);
	glEnd();
	//高的第三笔口最后一笔 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.40f, 0.00f);
    glVertex3f(1.01f, -0.40f, -0.10f);
    glVertex3f(1.01f, 0.40f, -0.10f);
    glVertex3f(1.01f, 0.40f, 0.00f);
	glEnd();
 	//高第四笔宝盖头上 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.70f, -0.20f);
    glVertex3f(1.01f, -0.70f, -0.20f);
    glVertex3f(1.01f, -0.70f, -0.30f);
    glVertex3f(1.01f, 0.70f, -0.30f);
	glEnd();
	//高第四笔宝盖头右 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.70f, -0.30f);
    glVertex3f(1.01f, -0.60f, -0.30f);
    glVertex3f(1.01f, -0.60f, -0.80f);
    glVertex3f(1.01f, -0.70f, -0.80f);
	glEnd();
	//高第四笔宝盖头左 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.70f, -0.30f);
    glVertex3f(1.01f, 0.60f, -0.30f);
    glVertex3f(1.01f, 0.60f, -0.80f);
    glVertex3f(1.01f, 0.70f, -0.80f);
	glEnd();
	//对称部分只需要改坐标2 
	//高第五笔口上 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.20f, -0.40f);
    glVertex3f(1.01f, -0.20f, -0.40f);
    glVertex3f(1.01f, -0.20f, -0.50f);
    glVertex3f(1.01f, 0.20f, -0.50f);
	glEnd();
	//高第五笔口左 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.20f, -0.50f);
    glVertex3f(1.01f, 0.10f, -0.50f);
    glVertex3f(1.01f, 0.10f, -0.70f);
    glVertex3f(1.01f, 0.20f, -0.70f);
	glEnd();
	//高第五笔口右 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, -0.20f, -0.50f);
    glVertex3f(1.01f, -0.10f, -0.50f);
    glVertex3f(1.01f, -0.10f, -0.70f);
    glVertex3f(1.01f, -0.20f, -0.70f);
	glEnd();
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f(1.01f, 0.20f, -0.70f);
    glVertex3f(1.01f, -0.20f, -0.70f);
    glVertex3f(1.01f, -0.20f, -0.80f);
    glVertex3f(1.01f, 0.20f, -0.80f);
	glEnd();
	//开始面3 
	//高的第一笔 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.10f, 1.01f,0.95f);
    glVertex3f( 0.15f, 1.01f,0.85f);
    glVertex3f( -0.15f,1.01f, 0.8f);
    glVertex3f( -0.10f,1.01f, 0.75f);
	glEnd();
 
    //高的第二笔 
    glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.70f,1.01f, 0.70f);
    glVertex3f( 0.70f, 1.01f,0.70f);
    glVertex3f( 0.70f, 1.01f,0.60f);
    glVertex3f( -0.70f,1.01f, 0.60f);
	glEnd();
	//高的第三笔口的上 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.40f,1.01f, 0.50f);
    glVertex3f( -0.40f,1.01f, 0.50f);
    glVertex3f( -0.40f,1.01f, 0.40f);
    glVertex3f( 0.40f,1.01f, 0.40f);
	glEnd();
	//高的第三笔口左 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.40f,1.01f, 0.40f);
    glVertex3f( 0.30f,1.01f, 0.40f);
    glVertex3f( 0.30f,1.01f, 0.00f);
    glVertex3f( 0.40f,1.01f, 0.00f);
	glEnd();
	//高的第三笔口右 
	 glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.30f,1.01f, 0.40f);
    glVertex3f( -0.40f,1.01f, 0.40f);
    glVertex3f( -0.40f,1.01f, 0.00f);
    glVertex3f( -0.30f,1.01f, 0.00f);
	glEnd();
	//高的第三笔口最后一笔 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.40f,1.01f, 0.00f);
    glVertex3f( -0.40f,1.01f, -0.10f);
    glVertex3f( 0.40f, 1.01f,-0.10f);
    glVertex3f( 0.40f, 1.01f,0.00f);
	glEnd();
 	//高第四笔宝盖头上 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.70f, 1.01f,-0.20f);
    glVertex3f( -0.70f,1.01f, -0.20f);
    glVertex3f( -0.70f,1.01f, -0.30f);
    glVertex3f( 0.70f, 1.01f,-0.30f);
	glEnd();              
	//高第四笔宝盖头右    
	glBegin(GL_QUADS);    
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.70f,1.01f,-0.30f);
    glVertex3f( -0.60f,1.01f,-0.30f);
    glVertex3f( -0.60f,1.01f,-0.80f);
    glVertex3f( -0.70f,1.01f,-0.80f);
	glEnd();
	//高第四笔宝盖头左 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.70f,1.01f,-0.30f);
    glVertex3f( 0.60f,1.01f,-0.30f);
    glVertex3f( 0.60f,1.01f,-0.80f);
    glVertex3f( 0.70f,1.01f,-0.80f);
	glEnd();             
	//对称部分只需要改坐标,2 
	//高第五笔口上       
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.20f, 1.01f,-0.40f);
    glVertex3f( -0.20f,1.01f, -0.40f);
    glVertex3f( -0.20f,1.01f, -0.50f);
    glVertex3f( 0.20f, 1.01f,-0.50f);
	glEnd();
	//高第五笔口左 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.20f,1.01f,-0.50f);
    glVertex3f( 0.10f,1.01f,-0.50f);
    glVertex3f( 0.10f,1.01f,-0.70f);
    glVertex3f( 0.20f,1.01f,-0.70f);
	glEnd();
	//高第五笔口右 
	glBegin(GL_QUADS);
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.20f,1.01f,-0.50f);
    glVertex3f( -0.10f,1.01f,-0.50f);
    glVertex3f( -0.10f,1.01f,-0.70f);
    glVertex3f( -0.20f,1.01f,-0.70f);
	glEnd();              
	glBegin(GL_QUADS);    
		glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.20f, 1.01f,-0.70f);
    glVertex3f( -0.20f,1.01f, -0.70f);
    glVertex3f( -0.20f,1.01f, -0.80f);
    glVertex3f( 0.20f, 1.01f,-0.80f);
	glEnd();
	
	//完成3面
	//开始画数字00 
	//数字面1 
	
	//左0 上 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.90f, -1.01f,0.70f);
    glVertex3f( 0.20f, -1.01f,0.70f);
    glVertex3f( 0.2f,-1.01f, 0.6f);
    glVertex3f( 0.9f,-1.01f, 0.6f);
	glEnd();
	//左0 左 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.90f, -1.01f,0.60f);
    glVertex3f( 0.80f, -1.01f,0.60f);
    glVertex3f( 0.8f,-1.01f, -0.6f);
    glVertex3f( 0.9f,-1.01f, -0.6f);
	glEnd();
	//左0 右 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.20f, -1.01f,0.60f);
    glVertex3f( 0.30f, -1.01f,0.60f);
    glVertex3f( 0.3f,-1.01f, -0.6f);
    glVertex3f( 0.2f,-1.01f, -0.6f);
	glEnd();
	
	//左0 下 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.90f, -1.01f,-0.70f);
    glVertex3f( 0.20f, -1.01f,-0.70f);
    glVertex3f( 0.2f,-1.01f, -0.6f);
    glVertex3f( 0.9f,-1.01f, -0.6f);
	glEnd();
	
	
	
		//右0 上 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.90f, -1.01f,0.70f);
    glVertex3f( -0.20f, -1.01f,0.70f);
    glVertex3f( -0.2f,-1.01f, 0.6f);
    glVertex3f( -0.9f,-1.01f, 0.6f);
	glEnd();
	//右0 左 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.90f, -1.01f,0.60f);
    glVertex3f( -0.80f, -1.01f,0.60f);
    glVertex3f( -0.8f,-1.01f, -0.6f);
    glVertex3f( -0.9f,-1.01f, -0.6f);
	glEnd();
	//右0 右 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.20f, -1.01f,0.60f);
    glVertex3f( -0.30f, -1.01f,0.60f);
    glVertex3f( -0.3f,-1.01f, -0.6f);
    glVertex3f( -0.2f,-1.01f, -0.6f);
	glEnd();
	
	//右0 上 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.90f, -1.01f,-0.70f);
    glVertex3f( -0.20f, -1.01f,-0.70f);
    glVertex3f( -0.2f,-1.01f, -0.6f);
    glVertex3f( -0.9f,-1.01f, -0.6f);
	glEnd();
	
	//数字面3
	
	//左0 上 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.90f, 0.70f,1.01f);
    glVertex3f( 0.20f, 0.70f,1.01f);
    glVertex3f( 0.2f, 0.6f,1.01f);
    glVertex3f( 0.9f, 0.6f,1.01f);
	glEnd();                 
	//左0 左 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.90f, 0.60f,1.01f);
    glVertex3f( 0.80f, 0.60f,1.01f);
    glVertex3f( 0.8f,  -0.6f,1.01f);
    glVertex3f( 0.9f,  -0.6f,1.01f);
	glEnd();
	//左0 右 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.20f, 0.60f,1.01f);
    glVertex3f( 0.30f, 0.60f,1.01f);
    glVertex3f( 0.3f,  -0.6f,1.01f);
    glVertex3f( 0.2f,  -0.6f,1.01f);
	glEnd();
	
	//左0 下 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.90f, -0.70f,1.01f);
    glVertex3f( 0.20f, -0.70f,1.01f);
    glVertex3f( 0.2f,   -0.6f,1.01f);
    glVertex3f( 0.9f,   -0.6f,1.01f);
	glEnd();
	
	
	
		//右0 上 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.90f, 0.70f,1.01f);
    glVertex3f( -0.20f, 0.70f,1.01f);
    glVertex3f( -0.2f,   0.6f,1.01f);
    glVertex3f( -0.9f,   0.6f,1.01f);
	glEnd();
	//右0 左 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.90f, 0.60f,1.01f);
    glVertex3f( -0.80f, 0.60f,1.01f);
    glVertex3f( -0.8f,  -0.6f,1.01f);
    glVertex3f( -0.9f,  -0.6f,1.01f);
	glEnd();
	//右0 右 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.20f,0.60f,1.01f);
    glVertex3f( -0.30f,0.60f,1.01f);
    glVertex3f( -0.3f, -0.6f,1.01f);
    glVertex3f( -0.2f, -0.6f,1.01f);
	glEnd();
	
	//右0 上 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.90f, -0.70f,1.01f);
    glVertex3f( -0.20f, -0.70f,1.01f);
    glVertex3f( -0.2f,   -0.6f,1.01f);
    glVertex3f( -0.9f,   -0.6f,1.01f);
	glEnd();
	
	//数字面12
	
	//左0 上 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.90f, 0.70f,-1.01f);
    glVertex3f( 0.20f, 0.70f,-1.01f);
    glVertex3f( 0.2f, 0.6f,-1.01f);
    glVertex3f( 0.9f, 0.6f,-1.01f);
	glEnd();                 
	//左0 左 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.90f, 0.60f,-1.01f);
    glVertex3f( 0.80f, 0.60f,-1.01f);
    glVertex3f( 0.8f,  -0.6f,-1.01f);
    glVertex3f( 0.9f,  -0.6f,-1.01f);
	glEnd();
	//左0 右 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.20f, 0.60f,-1.01f);
    glVertex3f( 0.30f, 0.60f,-1.01f);
    glVertex3f( 0.3f,  -0.6f,-1.01f);
    glVertex3f( 0.2f,  -0.6f,-1.01f);
	glEnd();
	
	//左0 下 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( 0.90f, -0.70f,-1.01f);
    glVertex3f( 0.20f, -0.70f,-1.01f);
    glVertex3f( 0.2f,   -0.6f,-1.01f);
    glVertex3f( 0.9f,   -0.6f,-1.01f);
	glEnd();
	
	
	
		//右0 上 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.90f, 0.70f,-1.01f);
    glVertex3f( -0.20f, 0.70f,-1.01f);
    glVertex3f( -0.2f,   0.6f,-1.01f);
    glVertex3f( -0.9f,   0.6f,-1.01f);
	glEnd();
	//右0 左 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.90f, 0.60f,-1.01f);
    glVertex3f( -0.80f, 0.60f,-1.01f);
    glVertex3f( -0.8f,  -0.6f,-1.01f);
    glVertex3f( -0.9f,  -0.6f,-1.01f);
	glEnd();
	//右0 右 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.20f,0.60f,-1.01f);
    glVertex3f( -0.30f,0.60f,-1.01f);
    glVertex3f( -0.3f, -0.6f,-1.01f);
    glVertex3f( -0.2f, -0.6f,-1.01f);
	glEnd();
	
	//右0 上 
     glBegin(GL_QUADS);
	glColor3f(1.0f, 1.0f, 1.0f);
    glVertex3f( -0.90f, -0.70f,-1.01f);
    glVertex3f( -0.20f, -0.70f,-1.01f);
    glVertex3f( -0.2f,   -0.6f,-1.01f);
    glVertex3f( -0.9f,   -0.6f,-1.01f);
	glEnd();
	
    angle++;
 
    glutSwapBuffers();
}
 
void reshape(int w, int h)
{
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45, (float)w / h, 0.1, 100);
    glMatrixMode(GL_MODELVIEW);
}
 
void timer(int value)
{
    glutPostRedisplay();
    glutTimerFunc(16, timer, 0);
}
 
int main(int argc, char * argv[])
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
 
    glutCreateWindow("好好好好麻烦啊");
 
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutTimerFunc(0, timer, 0);
 
    glEnable(GL_DEPTH_TEST);
 
    glutMainLoop();
 
    return EXIT_SUCCESS;
}
*/